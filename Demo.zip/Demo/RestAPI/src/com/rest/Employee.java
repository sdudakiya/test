package com.rest;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.*;
import javax.servlet.http.*;

//Importing JSON library for Rest API formatting

public class Employee extends HttpServlet{

	private String message;
	List<Map<String,String>> employeeList = new ArrayList<>();
	
	   public void init() throws ServletException {
	      // Do required initialization
	      message = "Hello World";
	   }

	   public void doGet(HttpServletRequest request, HttpServletResponse response)
	      throws ServletException, IOException {
		   	  // Set response content type
		      response.setContentType("text/html");

		      try {
		    	
		    	Map<String, String> employee1 = new HashMap<>();
		    	employee1.put("id", "121");
		    	employee1.put("name", "John Tiger");
		    	employee1.put("salary", "20000");

		    	Map<String, String> employee2 = new HashMap<>();
		    	employee2.put("id", "122");
		    	employee2.put("name", "Scott Jane");
		    	employee2.put("salary", "10000");

		    	Map<String, String> employee3 = new HashMap<>();
		    	employee3.put("id", "123");
		    	employee3.put("name", "Elli Green");
		    	employee3.put("salary", "29300");
		    	
		    	employeeList.add(employee1);
		    	employeeList.add(employee2);
		    	employeeList.add(employee3);
			} catch (Exception e) {
				// TODO: handle exception
			}
		      
		      // Actual logic goes here.
		      PrintWriter out = response.getWriter();
		      out.println("<h1>" + employeeList.toString() + "</h1>");
	   }
}
